var searchData=
[
  ['hash_20table_20serialization_20support',['Hash table serialization support',['../group__svn__hash__support.html',1,'']]],
  ['hook_2dsensitive_20wrappers_20for_20libsvn_5ffsroutines_2e',['Hook-sensitive wrappers for libsvn_fsroutines.',['../group__svn__repos__hook__wrappers.html',1,'']]]
];
