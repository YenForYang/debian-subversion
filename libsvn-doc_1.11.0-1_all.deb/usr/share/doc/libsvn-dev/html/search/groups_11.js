var searchData=
[
  ['uri_2furl_20conversion',['URI/URL conversion',['../group__svn__path__uri__stuff.html',1,'']]],
  ['update_20and_20switch_20_28update_2dlike_20functionality_29',['Update and switch (update-like functionality)',['../group__svn__wc__update__switch.html',1,'']]],
  ['upgrade_20a_20working_20copy_2e',['Upgrade a working copy.',['../group__Upgrade.html',1,'']]]
];
