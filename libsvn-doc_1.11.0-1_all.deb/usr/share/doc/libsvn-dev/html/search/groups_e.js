var searchData=
[
  ['revisions_20and_20peg_20revisions',['Revisions and Peg Revisions',['../group__clnt__revisions.html',1,'']]],
  ['remove_20files_2fdirectories_20from_20a_20working_20copy_20or_20repository_2e',['Remove files/directories from a working copy or repository.',['../group__Delete.html',1,'']]],
  ['ra_5fsvn_20low_2dlevel_20functions',['ra_svn low-level functions',['../group__ra__svn__deprecated.html',1,'']]],
  ['remove_20local_20changes_20in_20a_20repository_2e',['Remove local changes in a repository.',['../group__Revert.html',1,'']]],
  ['report_20interesting_20information_20about_20paths_20in_20the_20_20_20_20_20_20_20_20_20_20_20_20_20_20_20_20_20working_20copy_2e',['Report interesting information about paths in the                 working copy.',['../group__Status.html',1,'']]],
  ['reading_20and_20writing_20hashtables_20to_20disk',['Reading and writing hashtables to disk',['../group__svn__hash__read__write.html',1,'']]],
  ['repository_20relative_20urls',['Repository relative URLs',['../group__svn__path__repos__relative__urls.html',1,'']]],
  ['revision_20properties',['Revision properties',['../group__svn__props__revision__props.html',1,'']]],
  ['repository_20authorization_20callbacks',['Repository authorization callbacks',['../group__svn__repos__authz__callbacks.html',1,'']]],
  ['repository_20capabilities',['Repository capabilities',['../group__svn__repos__capabilities.html',1,'']]],
  ['repository_20lock_20wrappers',['Repository lock wrappers',['../group__svn__repos__fs__locks.html',1,'']]],
  ['repository_20notifications',['Repository notifications',['../group__svn__repos__notifications.html',1,'']]],
  ['repository_20locks',['Repository locks',['../group__svn__wc__repos__locks.html',1,'']]]
];
