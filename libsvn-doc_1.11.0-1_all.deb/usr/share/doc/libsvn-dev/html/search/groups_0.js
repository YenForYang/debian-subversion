var searchData=
[
  ['apr_20array_20compatibility_20helper_20macros',['APR Array Compatibility Helper Macros',['../group__APR__ARRAY__compat__macros.html',1,'']]],
  ['apr_20hash_20table_20helpers',['APR Hash Table Helpers',['../group__apr__hash__utilities.html',1,'']]],
  ['authentication_20functions',['Authentication functions',['../group__auth__fns.html',1,'']]],
  ['ascii_20character_20value_20constants',['ASCII character value constants',['../group__ctype__ascii.html',1,'']]],
  ['ascii_2dsubset_20case_20folding',['ASCII-subset case folding',['../group__ctype__case.html',1,'']]],
  ['apply_20a_20patch_20to_20the_20working_20copy',['Apply a patch to the working copy',['../group__Patch.html',1,'']]],
  ['adm_20access_20batons_20_28deprecated_29',['Adm access batons (deprecated)',['../group__svn__wc__adm__access.html',1,'']]]
];
