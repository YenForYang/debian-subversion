var searchData=
[
  ['valid_5ffrom',['valid_from',['../structsvn__auth__ssl__server__cert__info__t.html#a25082853d863ac6f3803616d41dcbb9d',1,'svn_auth_ssl_server_cert_info_t']]],
  ['valid_5foptions',['valid_options',['../structsvn__opt__subcommand__desc3__t.html#afd546f8b21dfc68c59c0e32ce4ee82d4',1,'svn_opt_subcommand_desc3_t::valid_options()'],['../structsvn__opt__subcommand__desc2__t.html#ab52ff885527b0b7a977e2836492a5785',1,'svn_opt_subcommand_desc2_t::valid_options()'],['../structsvn__opt__subcommand__desc__t.html#ab919b9b43b8654f9f15850c880d27c5f',1,'svn_opt_subcommand_desc_t::valid_options()']]],
  ['valid_5funtil',['valid_until',['../structsvn__auth__ssl__server__cert__info__t.html#a81f46ccdddf2611a86fe7c02e6227598',1,'svn_auth_ssl_server_cert_info_t']]],
  ['value',['value',['../structsvn__opt__revision__t.html#a3fd7428fac9e204434428c0e4376d98f',1,'svn_opt_revision_t::value()'],['../structsvn__prop__t.html#a3d36920ed6e21ada9c74a1829c4fb068',1,'svn_prop_t::value()']]],
  ['version',['version',['../structsvn__version__ext__loaded__lib__t.html#a858afcfcb5eb7f09987c403be6b490c2',1,'svn_version_ext_loaded_lib_t']]],
  ['version_5fnumber',['version_number',['../structsvn__client____shelf__version__t.html#acd9600434e20e003ac66d8e6f46b99ba',1,'svn_client__shelf_version_t']]],
  ['version_5fquery',['version_query',['../structsvn__version__checklist__t.html#a1c0516fe8fe4ed658f4a71ebdd9d58b6',1,'svn_version_checklist_t']]],
  ['versioned',['versioned',['../structsvn__client__status__t.html#ae34445e807c42edfe24162ef58031ecd',1,'svn_client_status_t::versioned()'],['../structsvn__wc__status3__t.html#acd4d0347e573fb396f9fad8d753e6bb8',1,'svn_wc_status3_t::versioned()']]]
];
