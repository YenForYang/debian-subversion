var searchData=
[
  ['handle_5ferror',['handle_error',['../structsvn__wc__entry__callbacks2__t.html#a2345a5ff02f00e55bc097073ba7c2279',1,'svn_wc_entry_callbacks2_t']]],
  ['handler',['handler',['../structsvn__ra__svn__cmd__entry__t.html#a67c05989c27c5370c655e6178ae22d57',1,'svn_ra_svn_cmd_entry_t']]],
  ['has_5fchildren',['has_children',['../structsvn__repos__log__entry__t.html#a0301d5284b4b9ec27d8b03beaf8259b7',1,'svn_repos_log_entry_t::has_children()'],['../structsvn__log__entry__t.html#a8c0a7858b5e6c77591fa14dcff113946',1,'svn_log_entry_t::has_children()']]],
  ['has_5fprop_5fmods',['has_prop_mods',['../structsvn__wc__entry__t.html#ac806a8e5b75fc6af61f0aea134e83146',1,'svn_wc_entry_t']]],
  ['has_5fprops',['has_props',['../structsvn__dirent__t.html#aaaffb32793273416764eb92642d2521e',1,'svn_dirent_t::has_props()'],['../structsvn__wc__entry__t.html#a3f28094ac4583c8ad05df2b07acbb92b',1,'svn_wc_entry_t::has_props()']]],
  ['has_5fwc_5finfo',['has_wc_info',['../structsvn__info__t.html#aae55dc251c9eb78f3cd1a276f0de30e9',1,'svn_info_t']]],
  ['help',['help',['../structsvn__opt__subcommand__desc3__t.html#ab86ee912cc28aea70c86485138278b4f',1,'svn_opt_subcommand_desc3_t::help()'],['../structsvn__opt__subcommand__desc2__t.html#a266800a041c3a4ffb852ca1a1b59bc78',1,'svn_opt_subcommand_desc2_t::help()'],['../structsvn__opt__subcommand__desc__t.html#ae245fde9d60c9809d2b03cc4ef5d65c2',1,'svn_opt_subcommand_desc_t::help()']]],
  ['hostname',['hostname',['../structsvn__auth__ssl__server__cert__info__t.html#af5c199081ea98c10ffb64db579986961',1,'svn_auth_ssl_server_cert_info_t']]],
  ['hunk_5ffuzz',['hunk_fuzz',['../structsvn__wc__notify__t.html#a5eb87ecfbbb79849cef7918eb7f34388',1,'svn_wc_notify_t']]],
  ['hunk_5fmatched_5fline',['hunk_matched_line',['../structsvn__wc__notify__t.html#a90222a852b8883f6eb97e202e8dbd6fe',1,'svn_wc_notify_t']]],
  ['hunk_5foriginal_5fstart',['hunk_original_start',['../structsvn__wc__notify__t.html#a845e0b3d57dbaf7d8295bac39e6b32d6',1,'svn_wc_notify_t']]],
  ['hunks',['hunks',['../structsvn__prop__patch__t.html#aec28fb70437479b01d7480d44bc239a5',1,'svn_prop_patch_t::hunks()'],['../structsvn__patch__t.html#ada5e71665e0f033b86b6592a4f932ef2',1,'svn_patch_t::hunks()']]],
  ['hash_20table_20serialization_20support',['Hash table serialization support',['../group__svn__hash__support.html',1,'']]],
  ['hook_2dsensitive_20wrappers_20for_20libsvn_5ffsroutines_2e',['Hook-sensitive wrappers for libsvn_fsroutines.',['../group__svn__repos__hook__wrappers.html',1,'']]]
];
