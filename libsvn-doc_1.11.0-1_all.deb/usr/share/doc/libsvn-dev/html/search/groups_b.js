var searchData=
[
  ['merge_20changes_20between_20branches_2e',['Merge changes between branches.',['../group__Merge.html',1,'']]],
  ['move_20paths_20in_20the_20working_20copy_20or_20repository_2e',['Move paths in the working copy or repository.',['../group__Move.html',1,'']]],
  ['mark_20conflicted_20paths_20as_20resolved_2e',['Mark conflicted paths as resolved.',['../group__Resolved.html',1,'']]],
  ['malfunctions_20and_20assertions',['Malfunctions and assertions',['../group__svn__error__malfunction__assertion.html',1,'']]],
  ['miscellaneous_20hash_20apis',['Miscellaneous hash APIs',['../group__svn__hash__misc.html',1,'']]],
  ['meta_2ddata_20properties',['Meta-data properties',['../group__svn__prop__meta__data.html',1,'']]],
  ['merging',['Merging',['../group__svn__wc__merging.html',1,'']]]
];
