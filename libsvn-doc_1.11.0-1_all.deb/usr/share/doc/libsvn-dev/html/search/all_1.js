var searchData=
[
  ['begin_20versioning_20files_2fdirectories_20in_20a_20working_20copy_2e',['Begin versioning files/directories in a working copy.',['../group__Add.html',1,'']]],
  ['backwards_5fcompatibility_5fbaton',['backwards_compatibility_baton',['../structsvn__client__status__t.html#a01ff05ad7b9c2d962c3549166cc6871f',1,'svn_client_status_t']]],
  ['base64_20encoding_2fdecoding_20functions',['Base64 encoding/decoding functions',['../group__base64.html',1,'']]],
  ['base_5fabspath',['base_abspath',['../structsvn__wc__conflict__description2__t.html#ac0d0e48c0b337be4c588cb1fdc5404b4',1,'svn_wc_conflict_description2_t']]],
  ['base_5ffile',['base_file',['../structsvn__wc__conflict__description__t.html#a48dc9fea03417e910989cc4603b56db0',1,'svn_wc_conflict_description_t']]],
  ['binary_5fpatch',['binary_patch',['../structsvn__patch__t.html#ad5753b71acd50912c42ca71a46de16e6',1,'svn_patch_t']]],
  ['blocksize',['blocksize',['../structsvn__stringbuf__t.html#a81d1126b261bc2fa0147edaaa1a5ed30',1,'svn_stringbuf_t']]],
  ['basic_20character_20classification_20_2d_207_2dbit_20ascii_20only',['Basic character classification - 7-bit ASCII only',['../group__ctype__basic.html',1,'']]],
  ['built_2din_20back_2dends',['Built-in back-ends',['../group__svn__fs__backend__names.html',1,'']]],
  ['berkeley_20db_20filesystems',['Berkeley DB filesystems',['../group__svn__fs__bdb.html',1,'']]],
  ['berkeley_20db_20filesystem_20compatibility',['Berkeley DB filesystem compatibility',['../group__svn__fs__bdb__deprecated.html',1,'']]],
  ['bitmask_20flags_20for_20svn_5ffs_5fbegin_5ftxn2_28_29',['Bitmask flags for svn_fs_begin_txn2()',['../group__svn__fs__begin__txn2__flags.html',1,'']]],
  ['bring_20a_20working_20copy_20up_2dto_2ddate_20with_20a_20repository',['Bring a working copy up-to-date with a repository',['../group__Update.html',1,'']]]
];
