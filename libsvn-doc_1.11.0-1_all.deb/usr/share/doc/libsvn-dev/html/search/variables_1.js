var searchData=
[
  ['backwards_5fcompatibility_5fbaton',['backwards_compatibility_baton',['../structsvn__client__status__t.html#a01ff05ad7b9c2d962c3549166cc6871f',1,'svn_client_status_t']]],
  ['base_5fabspath',['base_abspath',['../structsvn__wc__conflict__description2__t.html#ac0d0e48c0b337be4c588cb1fdc5404b4',1,'svn_wc_conflict_description2_t']]],
  ['base_5ffile',['base_file',['../structsvn__wc__conflict__description__t.html#a48dc9fea03417e910989cc4603b56db0',1,'svn_wc_conflict_description_t']]],
  ['binary_5fpatch',['binary_patch',['../structsvn__patch__t.html#ad5753b71acd50912c42ca71a46de16e6',1,'svn_patch_t']]],
  ['blocksize',['blocksize',['../structsvn__stringbuf__t.html#a81d1126b261bc2fa0147edaaa1a5ed30',1,'svn_stringbuf_t']]]
];
