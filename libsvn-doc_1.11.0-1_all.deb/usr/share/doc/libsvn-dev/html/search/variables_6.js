var searchData=
[
  ['get_5fclient_5fstring',['get_client_string',['../structsvn__ra__callbacks2__t.html#a84728cc834176b36a62e3bd82b2601a8',1,'svn_ra_callbacks2_t']]],
  ['get_5fcommit_5feditor',['get_commit_editor',['../structsvn__ra__plugin__t.html#a36f412e11d25fe90326117bce532b06a',1,'svn_ra_plugin_t']]],
  ['get_5fdated_5frevision',['get_dated_revision',['../structsvn__ra__plugin__t.html#a557ef7c6499e9bc920adcca68f2f6179',1,'svn_ra_plugin_t']]],
  ['get_5fdir',['get_dir',['../structsvn__ra__plugin__t.html#a21f2f3d34cafa2f91ff49c564552d1ba',1,'svn_ra_plugin_t']]],
  ['get_5ffile',['get_file',['../structsvn__ra__plugin__t.html#a25b85add88f9ec276709b8af157322c7',1,'svn_ra_plugin_t']]],
  ['get_5ffile_5frevs',['get_file_revs',['../structsvn__ra__plugin__t.html#a0b78d81849d342d4b524e557ed6d5dca',1,'svn_ra_plugin_t']]],
  ['get_5flatest_5frevnum',['get_latest_revnum',['../structsvn__ra__plugin__t.html#ae4f7515ac4aef31f46f3cb21f8ba721d',1,'svn_ra_plugin_t']]],
  ['get_5flocations',['get_locations',['../structsvn__ra__plugin__t.html#a74294554ad4c11caf71e1c4e41e99fcb',1,'svn_ra_plugin_t']]],
  ['get_5flog',['get_log',['../structsvn__ra__plugin__t.html#afe4bc2c1358c07e10afb4337905d8f2a',1,'svn_ra_plugin_t']]],
  ['get_5frepos_5froot',['get_repos_root',['../structsvn__ra__plugin__t.html#a149089652b864d23622dd7bd8e1b5e5e',1,'svn_ra_plugin_t']]],
  ['get_5fuuid',['get_uuid',['../structsvn__ra__plugin__t.html#a509fdc2c529603f93bb1bb9dfea9aa51',1,'svn_ra_plugin_t']]],
  ['get_5fversion',['get_version',['../structsvn__ra__plugin__t.html#a987578cd1a5cda4753067b9c4f9bd265',1,'svn_ra_plugin_t']]],
  ['get_5fwc_5fcontents',['get_wc_contents',['../structsvn__ra__callbacks2__t.html#abac945409fe4861749b64f48f9a9312c',1,'svn_ra_callbacks2_t']]],
  ['get_5fwc_5fprop',['get_wc_prop',['../structsvn__ra__callbacks2__t.html#a2201deaeed805e764c6ffa3b2b9ab0ea',1,'svn_ra_callbacks2_t']]]
];
