var searchData=
[
  ['import_20files_20into_20the_20repository_2e',['Import files into the repository.',['../group__Import.html',1,'']]],
  ['invisible_20properties',['Invisible properties',['../group__svn__prop__invisible__props.html',1,'']]],
  ['ignoring_20unversioned_20files_20and_20directories',['Ignoring unversioned files and directories',['../group__svn__wc__ignore.html',1,'']]]
];
