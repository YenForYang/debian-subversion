var searchData=
[
  ['node_20location_20segment_20reporting_2e',['Node location segment reporting.',['../group__node__location__seg__reporting.html',1,'']]],
  ['name_20of_20subversion_27s_20admin_20dir',['Name of Subversion&apos;s admin dir',['../group__svn__wc__adm__dir__name.html',1,'']]],
  ['notification_20callback_20handling',['Notification callback handling',['../group__svn__wc__notifications.html',1,'']]]
];
