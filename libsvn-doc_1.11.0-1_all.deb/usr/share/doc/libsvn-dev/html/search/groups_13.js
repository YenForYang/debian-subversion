var searchData=
[
  ['working_20copy_20management',['Working copy management',['../group__svn__wc.html',1,'']]],
  ['working_20copy_20context',['Working copy context',['../group__svn__wc__context.html',1,'']]],
  ['working_20copy_20roots',['Working copy roots',['../group__svn__wc__roots.html',1,'']]],
  ['working_20copy_20status_2e',['Working copy status.',['../group__svn__wc__status.html',1,'']]],
  ['wc_20out_2dof_2ddate_20info_20from_20the_20repository',['WC out-of-date info from the repository',['../group__svn__wc__status__ood.html',1,'']]]
];
