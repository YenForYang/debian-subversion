var searchData=
[
  ['tree_20deltas',['Tree deltas',['../group__svn__delta__tree__deltas.html',1,'']]],
  ['text_20deltas',['Text deltas',['../group__svn__delta__txt__delta.html',1,'']]],
  ['taking_20the_20diff_20of_20two_20hash_20tables_2e',['Taking the diff of two hash tables.',['../group__svn__hash__diff.html',1,'']]],
  ['text_2fprop_20deltas_20using_20an_20editor',['Text/Prop Deltas Using an Editor',['../group__svn__wc__deltas.html',1,'']]],
  ['translation_20flags',['Translation flags',['../group__translate__flags.html',1,'']]]
];
