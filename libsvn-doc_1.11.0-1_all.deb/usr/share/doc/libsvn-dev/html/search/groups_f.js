var searchData=
[
  ['show_20modification_20information_20about_20lines_20in_20a_20file_2e',['Show modification information about lines in a file.',['../group__Blame.html',1,'']]],
  ['show_20repository_20information_20about_20a_20working_20copy_2e',['Show repository information about a working copy.',['../group__Info.html',1,'']]],
  ['switch_20a_20working_20copy_20to_20a_20different_20repository_2e',['Switch a working copy to a different repository.',['../group__Relocate.html',1,'']]],
  ['shelves_20and_20checkpoints',['Shelves and checkpoints',['../group__svn__client__shelves__checkpoints.html',1,'']]],
  ['string_20handling',['String handling',['../group__svn__string.html',1,'']]],
  ['svn_5fstring_5ft_20functions',['svn_string_t functions',['../group__svn__string__svn__string__t.html',1,'']]],
  ['svn_5fstringbuf_5ft_20functions',['svn_stringbuf_t functions',['../group__svn__string__svn__stringbuf__t.html',1,'']]],
  ['switch_20a_20working_20copy_20to_20another_20location_2e',['Switch a working copy to another location.',['../group__Switch.html',1,'']]]
];
