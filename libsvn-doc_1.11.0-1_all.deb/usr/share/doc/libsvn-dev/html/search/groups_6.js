var searchData=
[
  ['generate_20differences_20between_20paths_2e',['Generate differences between paths.',['../group__Diff.html',1,'']]],
  ['generic_20byte_20streams',['Generic byte streams',['../group__svn__io__byte__streams.html',1,'']]]
];
